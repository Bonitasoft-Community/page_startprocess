The Scooter page display a QRCODE. Simply scan it by your mobile, and you will access immediately on the Bonita Portal for mobile

<img src="screenshoot_scooter.jpg"/>
